from django.conf.urls import url


from django.contrib import admin
from . import views

urlpatterns=[

    url(r'^sign_up/',views.register_user,name='register_user'),
    url(r'^register_success/$', views.register_success,name='register_success'),
    url(r'^confirm/(?P<activation_key>\w+)/$', views.register_confirm,name='register_confirm'),
]
